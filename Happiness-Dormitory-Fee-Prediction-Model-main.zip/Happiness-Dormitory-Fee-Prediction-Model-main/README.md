# Happiness-Dormitory-Fee-Prediction-Model
we predict happiness dormitory fee in Korea
